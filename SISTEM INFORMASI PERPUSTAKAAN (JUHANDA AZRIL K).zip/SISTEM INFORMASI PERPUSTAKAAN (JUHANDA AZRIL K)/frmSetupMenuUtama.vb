﻿Public Class frmSetupMenuUtama

    Private Sub KeluarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles KeluarToolStripMenuItem.Click
        If MessageBox.Show("Anda yakin ingin keluar?", "Validasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            Application.Exit()
        End If
    End Sub

    Private Sub GantiPWToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GantiPWToolStripMenuItem.Click
        frmGantiPASSWORD.ShowDialog()
    End Sub

    Private Sub BUKUToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BUKUToolStripMenuItem.Click
        frmMasterBuku.MdiParent = Me
        frmMasterBuku.WindowState = FormWindowState.Maximized
        frmMasterBuku.Show()

    End Sub

    Private Sub ANGGOTAToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ANGGOTAToolStripMenuItem.Click
        frmMasterAnggota.MdiParent = Me
        frmMasterAnggota.WindowState = FormWindowState.Maximized
        frmMasterAnggota.Show()


    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click

        If MessageBox.Show("Anda yakin ingin log out?", "Validasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            frmLogin.Show()
            Me.Close()

        End If


    End Sub
End Class