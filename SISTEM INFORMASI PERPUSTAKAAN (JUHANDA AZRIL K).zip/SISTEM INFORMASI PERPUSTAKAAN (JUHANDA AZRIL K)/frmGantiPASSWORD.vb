﻿Public Class frmGantiPASSWORD

    Private Sub btnGanti_Clicked(sender As Object, e As EventArgs) Handles btnGanti.Click

        If TextBox2.Text <> TextBox3.Text Then
            MsgBox("Password baru dan konfirmasi tidak sesuai")
            TextBox2.Text = ""
            TextBox3.Text = ""
        Else
            If TextBox1.Text = frmLogin.datatab.Select()(0).Item("PASSWORD") Then
                eksekusiSQL("UPDATE pengguna SET PASSWORD = '" & TextBox2.Text & "' WHERE ID = '" & frmLogin.id & "'")
                MsgBox("Password berhasil diganti!")
                Me.Close()
            Else
                MsgBox("Password SALAH !")
            End If

        End If

    End Sub
End Class