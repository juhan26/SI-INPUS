﻿Public Class frmMasterBuku

    Public barisdipilih As Integer
    Dim tampung As DataTable
    Dim ID As Integer

    Sub tampildata()
        tampung = eksekusiSQL("SELECT * FROM buku ")
        DataGridView1.DataSource = tampung
    End Sub

    Sub refreshdata()
        tampildata()
        txtjudul.Text = ""
        txtkategori.Text = ""
        txtpenerbit.Text = ""
        txttahunterbit.Value = 0
        txtjumlahhal.Value = 0
        txtharga.Value = 0
        txtdeskripsi.Text = ""
        txtjudul.Focus()
        ID = 0
        comboboxlist("buku", "KATEGORI", txtkategori)
        comboboxlist("buku", "PENERBIT", txtpenerbit)
        GroupBox1.Text = "Detail Buku"
    End Sub

    Sub simpandata()
        If txtjudul.Text = "" Or txtkategori.Text = "" Or txtpenerbit.Text = "" Or txttahunterbit.Value = 0 Or txtjumlahhal.Value = 0 Or txtharga.Value = 0 Or txtdeskripsi.Text = "" Then
            MessageBox.Show("Judul buku, kategori, penerbit, tahun terbit, jumlah halaman, harga, dan deskripsi, wajib di isi", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If ID = 0 Then
            tampil("INSERT INTO `buku`(`JUDUL_BUKU`, `KATEGORI`, `PENERBIT`, `TAHUN_TERBIT`, `JUMLAH_HALAMAN`, `HARGA`, `DESKRIPSI`) VALUES ('" & txtjudul.Text & "','" & txtkategori.Text & "','" & txtpenerbit.Text & "','" & txttahunterbit.Value & "','" & txtjumlahhal.Value & "','" & txtharga.Value & "','" & txtdeskripsi.Text & "')")
            tampildata()
            MessageBox.Show("Data Berhasil Disimpan", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            refreshdata()
        Else
            tampil("UPDATE `buku` SET `JUDUL_BUKU`='" & txtjudul.Text & "',`KATEGORI`='" & txtkategori.Text & "',`PENERBIT`='" & txtpenerbit.Text & "',`TAHUN_TERBIT`='" & txttahunterbit.Value & "',`JUMLAH_HALAMAN`='" & txtjumlahhal.Value & "',`HARGA`='" & txtharga.Value & "',`DESKRIPSI`='" & txtdeskripsi.Text & "' WHERE `ID` = '" & ID & "'")
            tampildata()
            MessageBox.Show("Berhasil Mengubah Data", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            refreshdata()
        End If
    End Sub

    Sub ubahdata()

        If DataGridView1.RowCount = 0 Then
            MessageBox.Show("Tidak ada data yang dipilih untuk diubah", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        If btnubah.Text = "UBAH" Then
            Dim barisdipilih As Integer = DataGridView1.CurrentRow.Index
            ID = DataGridView1.Rows(barisdipilih).Cells("ID").Value
            txtjudul.Text = DataGridView1.Rows(barisdipilih).Cells("Judul_buku").Value
            txtkategori.Text = DataGridView1.Rows(barisdipilih).Cells("Kategori").Value
            txtpenerbit.Text = DataGridView1.Rows(barisdipilih).Cells("Penerbit").Value
            txttahunterbit.Value = DataGridView1.Rows(barisdipilih).Cells("Tahun_terbit").Value
            txtjumlahhal.Value = DataGridView1.Rows(barisdipilih).Cells("Jumlah_halaman").Value
            txtharga.Value = DataGridView1.Rows(barisdipilih).Cells("Harga").Value
            txtdeskripsi.Text = DataGridView1.Rows(barisdipilih).Cells("Deskripsi").Value
            txtjudul.Text = Focus()
            GroupBox1.Text = "Ubah data buku"
        End If
    End Sub

    Sub hapusdata()
        If DataGridView1.RowCount = 0 Then
            MessageBox.Show("Tidak ada data yang di hapus", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If MessageBox.Show("Yakin ingin menghapus data?", "INFORMASI", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            barisdipilih = DataGridView1.CurrentRow.Index
            ID = DataGridView1.Rows(barisdipilih).Cells("ID").Value
            Dim tampung As DataTable = eksekusiSQL("delete from `buku` where `ID` = " & ID & "")
            refreshdata()
        End If
    End Sub

    Sub cetakdata()

    End Sub

    Sub tutup()
        Me.Close()
    End Sub

    Private Sub frmMasterBuku_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyCode
            Case e.Control And Keys.S
                simpandata()
            Case Keys.F5
                refreshdata()
            Case Keys.F2
                ubahdata()
            Case e.Control And Keys.D
                hapusdata()
            Case e.Control And Keys.P
                cetakdata()
            Case Keys.Escape
                tutup()
        End Select
    End Sub

    Private Sub frmMasterBuku_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        tampildata()
        Me.KeyPreview = True

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btntutup.Click
        tutup()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        simpandata()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        refreshdata()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        hapusdata()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtcari.TextChanged

        tampung = eksekusiSQL("select * from buku where judul_buku like '%" & txtcari.Text & "%'")
        DataGridView1.DataSource = tampung

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnubah.Click
        ubahdata()
    End Sub

End Class