﻿Public Class frmMasterPengguna

    Public barisdipilih As Integer
    Dim tampung As DataTable
    Dim ID As Integer

    Sub tampildata()
        tampung = eksekusiSQL("SELECT * FROM pengguna ")
        DataGridView1.DataSource = tampung
        DataGridView1.Columns("PASSWORD").Visible = False 'menyembunyikan kolom password pada tabel

    End Sub

    Sub refreshdata()
        tampildata()
        txtpengguna.Text = ""
        txtjeniskelamin.SelectedIndex = -1
        txttempatlahir.Text = ""
        txtalamat.Text = ""
        txtnotelepon.Text = ""
        txtusername.Text = ""
        txtpassword.Text = ""
        txtakses.Text = ""
        txtdeskripsi.Text = ""
        txtpengguna.Focus()
        ID = 0
        comboboxlist("pengguna", "TEMPAT_LAHIR", txttempatlahir)
        GroupBox1.Text = "Detail User"
    End Sub

    Sub simpandata()
        If txtpengguna.Text = "" Or txtjeniskelamin.Text = "" Or txttempatlahir.Text = "" Or txttanggallahir.Text = "" Or txtalamat.Text = "" Or txtnotelepon.Text = "" Or txtusername.Text = "" Or txtpassword.Text = "" Or txtakses.Text = "" Then
            MessageBox.Show("Nama Pengguna, Jenis Kelamin, Tempat Lahir, Tanggal Lahir, Alamat, No Telepon, Username, Password, dan hak cipta wajib di isi", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If ID = 0 Then
            tampil("INSERT INTO `pengguna`(`NAMA_PENGGUNA`, `JENIS_KELAMIN`, `TEMPAT_LAHIR`, `TANGGAL_LAHIR`, `ALAMAT`, `NOMOR_TELEPON`, `USERNAME`, `PASSWORD`, `HAK_AKSES`, `DESKRIPSI`) VALUES ('" & txtpengguna.Text & "','" & txtjeniskelamin.Text & "','" & txttempatlahir.Text & "','" & Format(txttanggallahir.Value, "yyyy-MM-dd") & "','" & txtalamat.Text & "','" & txtnotelepon.Text & "','" & txtusername.Text & "','" & txtpassword.Text & "','" & txtakses.Text & "','" & txtdeskripsi.Text & "')")
            tampildata()
            MessageBox.Show("Data Berhasil Disimpan", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            refreshdata()
        Else
            tampil("UPDATE `pengguna` SET `NAMA_PENGGUNA`='" & txtpengguna.Text & "',`JENIS_KELAMIN`='" & txtjeniskelamin.Text & "',`TEMPAT_LAHIR`='" & txttempatlahir.Text & "',`TANGGAL_LAHIR`='" & Format(txttanggallahir.Value, "yyyy-MM-dd") & "',`ALAMAT`='" & txtalamat.Text & "',`NOMOR_TELEPON`='" & txtnotelepon.Text & "',`USERNAME`='" & txtusername.Text & "',`PASSWORD`='" & txtpassword.Text & "',`HAK_AKSES`='" & txtakses.Text & "',`DESKRIPSI`='" & txtdeskripsi.Text & "' WHERE `ID` = '" & ID & "'")
            tampildata()
            MessageBox.Show("Berhasil Mengubah Data", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            refreshdata()
        End If
    End Sub

    Sub ubahdata()

        If DataGridView1.RowCount = 0 Then
            MessageBox.Show("Tidak ada data yang dipilih untuk diubah", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        Else
            Dim barisdipilih As Integer = DataGridView1.CurrentRow.Index
            ID = DataGridView1.Rows(barisdipilih).Cells("ID").Value
            txtpengguna.Text = DataGridView1.Rows(barisdipilih).Cells("NAMA_PENGGUNA").Value
            txtjeniskelamin.Text = DataGridView1.Rows(barisdipilih).Cells("JENIS_KELAMIN").Value
            txttempatlahir.Text = DataGridView1.Rows(barisdipilih).Cells("TEMPAT_LAHIR").Value
            txttanggallahir.Value = DataGridView1.Rows(barisdipilih).Cells("TANGGAL_LAHIR").Value
            txtalamat.Text = DataGridView1.Rows(barisdipilih).Cells("ALAMAT").Value
            txtnotelepon.Text = DataGridView1.Rows(barisdipilih).Cells("NOMOR_TELEPON").Value
            txtusername.Text = DataGridView1.Rows(barisdipilih).Cells("USERNAME").Value
            txtpassword.Text = DataGridView1.Rows(barisdipilih).Cells("PASSWORD").Value
            txtakses.Text = DataGridView1.Rows(barisdipilih).Cells("HAK_AKSES").Value
            txtdeskripsi.Text = DataGridView1.Rows(barisdipilih).Cells("DESKRIPSI").Value
            txtpengguna.Focus()
            GroupBox1.Text = "Ubah data User"
        End If
    End Sub

    Sub hapusdata()
        If DataGridView1.RowCount = 0 Then
            MessageBox.Show("Tidak ada data yang di hapus", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If MessageBox.Show("Yakin ingin menghapus data?", "INFORMASI", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            barisdipilih = DataGridView1.CurrentRow.Index
            ID = DataGridView1.Rows(barisdipilih).Cells("ID").Value
            Dim tampung As DataTable = eksekusiSQL("delete from `pengguna` where `ID` = " & ID & "")
            refreshdata()
        End If
    End Sub

    Sub cetakdata()

    End Sub

    Sub tutup()
        Me.Close()
    End Sub

    Private Sub frmMasterPengguna_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyCode
            Case e.Control And Keys.S
                simpandata()
            Case Keys.F5
                refreshdata()
            Case Keys.F2
                ubahdata()
            Case e.Control And Keys.D
                hapusdata()
            Case e.Control And Keys.P
                cetakdata()
            Case Keys.Escape
                tutup()
        End Select
    End Sub

    Private Sub frmMasterPengguna_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        tampildata()
        Me.KeyPreview = True

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btntutup.Click
        tutup()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        simpandata()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        refreshdata()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        hapusdata()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtcari.TextChanged

        tampung = eksekusiSQL("select * from pengguna where NAMA_PENGGUNA like '%" & txtcari.Text & "%'")
        DataGridView1.DataSource = tampung

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnubah.Click
        ubahdata()
    End Sub
End Class