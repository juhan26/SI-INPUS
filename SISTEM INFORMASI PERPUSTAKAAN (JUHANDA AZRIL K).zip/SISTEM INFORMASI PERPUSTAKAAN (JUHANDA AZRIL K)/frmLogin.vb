﻿Public Class frmLogin

    Public datatab As DataTable
    Public id As Integer


    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            txtpw.UseSystemPasswordChar = False
        Else
            txtpw.UseSystemPasswordChar = True
        End If
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        datatab = eksekusiSQL("SELECT * FROM pengguna WHERE USERNAME='" & txtuser.Text & "' AND PASSWORD='" & txtpw.Text & "'")
        If datatab.Rows.Count > 0 Then
            MsgBox("Berhasil Login!")
            frmSetupMenuUtama.statusnama.Text = datatab.Select()(0).Item("NAMA_PENGGUNA")
            frmSetupMenuUtama.statushak.Text = datatab.Select()(0).Item("HAK_AKSES")
            id = datatab.Select()(0).Item("ID")
            frmSetupMenuUtama.Show()
            Me.Close()
        Else
            MsgBox("DATA TIDAK DI TEMUKAN!")
        End If

    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtpw.UseSystemPasswordChar = True
        txtuser.Focus()
    End Sub

    
End Class