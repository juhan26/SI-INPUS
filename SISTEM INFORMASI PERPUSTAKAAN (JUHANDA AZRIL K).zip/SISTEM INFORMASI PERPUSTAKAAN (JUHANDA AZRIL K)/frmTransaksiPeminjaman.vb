﻿Public Class frmTransaksiPeminjaman

    Dim tampung As DataTable

    Sub tampiltable()
        tampung = eksekusiSQL("select ID_BUKU, JUDUL_BUKU, JUMLAH from peminjaman_detail,buku where id='000'")
        DataGridView1.DataSource = tampung

    End Sub
    Sub tampiljudulbuku()
        Dim DataBuku = eksekusiSQL("select judul_buku from buku where id='" & txtidbuku.Text & "'").Select()
        If DataBuku.Length > 0 Then
            txtjudulbuku.Text = DataBuku(0).Item("JUDUL_BUKU")
            txtjumlah.Value = 1
            txtjumlah.Focus()
        Else
            MessageBox.Show("ID BUKU TIDAK DITEMUKAN", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If

    End Sub
    Sub caribuku()
        frmListBuku.ShowDialog()
    End Sub
    Sub tambahbuku()
        If txtidbuku.Text = "" Or txtjudulbuku.Text = "" Or txtjumlah.Value <= 0 Then
            MessageBox.Show("ID BUKU, JUDUL BUKU DAN JUMLAH MOHON DIISI", "VALIDASI", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Dim cariIDBUKU = tampung.Select("ID_BUKU = '" & txtidbuku.Text & "'")
        If cariIDBUKU.Length <= 0 Then
            Dim barisbaru = tampung.NewRow
            barisbaru.Item("ID_BUKU") = txtidbuku.Text
            barisbaru.Item("JUDUL_BUKU") = txtjudulbuku.Text
            barisbaru.Item("JUMLAH") = txtjumlah.Value
            tampung.Rows.Add(barisbaru)
        Else

            cariIDBUKU(0).Item("JUMLAH") = cariIDBUKU(0).Item("JUMLAH") + txtjumlah.Value

        End If




    End Sub
    Sub hapusbuku()
        If DataGridView1.RowCount = 0 Then
            MessageBox.Show("Tidak ada data yang di hapus", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If MessageBox.Show("Yakin ingin menghapus data?", "INFORMASI", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Dim barisindex As Integer = DataGridView1.CurrentRow.Index
            DataGridView1.Rows.RemoveAt(barisindex)
        End If
    End Sub
    Sub tampilanggota()
        comboboxlistconcat("anggota", "ID,' - ',NAMA_ANGGOTA", txtanggota)

    End Sub
    Sub refreshdata()
        tampiltable()
        txtjudulbuku.Text = ""
        txtidbuku.Text = ""
        txtjumlah.Value = 0
        txttanggal.Value = Now
        txtanggota.SelectedIndex = -1
        txtidbuku.Focus()
        tampilanggota()
    End Sub
    Sub simpandata()
        If DataGridView1.RowCount <= 0 Then
            MessageBox.Show("Tidak Ada data buku yang di simpan", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        ElseIf txttanggal.Text = "" Or txtanggota.SelectedIndex = -1 Then
            MessageBox.Show("Tanggal, dan Anggota wajib diisi!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Dim IDTranksaksi = eksekusiSQL("select if(max(ID)>0,max(ID),0)+1 as NilaiOtomatis from Peminjaman").Select()(0).Item("NilaiOtomatis")

        eksekusiSQL("INSERT INTO `peminjaman`(`ID`, `ID_ANGGOTA`, `TANGGAL`, `TANGGAL_KEMBALI`, `HARI_PINJAM`, `TOTAL_DENDA`, `STATUS`, `DESKRIPSI`, `ID_PENGGUNA`) VALUES ('" & IDTranksaksi & "','" & txtanggota.Text.Split(" - ")(0) & "','" & Format(txttanggal.Value, "yyyy-MM-dd HH:mm:ss") & "','" & Format(txttanggal.Value.AddDays(My.Settings.trkJumlahHariPinjam)) & "','" & My.Settings.trkJumlahHariPinjam & "','0','DIPINJAM','','" & My.Settings.lgnID & "')")

        For Each isi In tampung.Select()
            eksekusiSQL("INSERT INTO `peminjaman_detail`(`ID_PEMINJAMAN`, `ID_BUKU`, `JUMLAH`, `DENDA`, `DESKRIPSI`) VALUES ('" & IDTranksaksi & "','" & isi.Item("ID_BUKU") & "','" & isi.Item("JUMLAH") & "','0','')")
        Next
        refreshdata()
        MessageBox.Show("Data berhasil disimpan.", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Sub tutup()

        If DataGridView1.Rows.Count = 0 Then
            Me.Close()
        Else
            If MessageBox.Show("Yakin ingin menutup?", "Validasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Me.Close()
            End If
        End If
    End Sub

    Private Sub frmTransaksiPeminjaman_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyCode
            Case Keys.F1
                caribuku()
            Case e.Control And Keys.T
                tambahbuku()
            Case e.Control And Keys.Delete
                hapusbuku()
            Case e.Control And Keys.S
                simpandata()
            Case Keys.F5
                refreshdata()
            Case Keys.Escape
                tutup()
        End Select
    End Sub

    Private Sub frmTransaksiPeminjaman_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.KeyPreview = True
        refreshdata()
    End Sub

    Private Sub txtIDBUKU_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtidbuku.KeyPress
        If e.KeyChar = Chr(13) Then
            tampiljudulbuku()
        Else
            txtjudulbuku.Text = ""
        End If
    End Sub

    Private Sub btnTAMBAH_Click(sender As Object, e As EventArgs) Handles btnTambah.Click
        tambahbuku()
    End Sub

    Private Sub btnHAPUS_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        hapusbuku()
    End Sub

    Private Sub btnREFRESH_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        refreshdata()
    End Sub

    Private Sub btnTUTUP_Click(sender As Object, e As EventArgs) Handles btntutup.Click
        tutup()
    End Sub

    Private Sub btnSIMPAN_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        simpandata()
    End Sub

    Private Sub btnCari_Click(sender As Object, e As EventArgs) Handles btnCari.Click

        caribuku()

    End Sub
End Class