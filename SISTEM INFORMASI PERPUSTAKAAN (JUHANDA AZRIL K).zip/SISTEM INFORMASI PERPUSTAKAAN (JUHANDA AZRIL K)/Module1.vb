﻿Imports MySql.Data.MySqlClient

Module Module1

    Sub tampil(ByVal qwerty As String)
        Dim alamat As String = "server=localhost;uid=root;database=dbsiinpus22117690"
        Dim koneksi As New MySqlConnection(alamat)
        Dim eksekusi As New MySqlDataAdapter(qwerty, koneksi)
        Dim tampung As New DataTable
        eksekusi.Fill(tampung)
    End Sub

    Function eksekusiSQL(ByVal PerintahSQL As String) As DataTable

        Dim alamat As String = "server=localhost;uid=root;database=dbsiinpus22117690"
        Dim koneksi As New MySqlConnection(alamat)
        Dim eksekusi As New MySqlDataAdapter(PerintahSQL, koneksi)
        Dim tampung As New DataTable
        eksekusi.Fill(tampung)
        Return tampung
    End Function

    Sub comboboxlist(ByVal namatabel As String, ByVal namakolom As String, ByVal namacombobox As System.Windows.Forms.ComboBox)

        Dim data = eksekusiSQL("select distinct(" & namakolom & ") from " & namatabel & "")
        namacombobox.Items.Clear()
        For Each isi In data.Select()
            namacombobox.Items.Add(isi.Item(namakolom))
        Next

    End Sub
    Sub comboboxlistconcat(ByVal Namatabel As String, ByVal StringConnect As String, ByVal NamaCombobox As System.Windows.Forms.ComboBox)

        Dim data = eksekusiSQL("select distinct(concat(" & StringConnect & ")) as dataconcat from " & Namatabel & "")
        NamaCombobox.Items.Clear()
        For Each isi In data.Select()
            NamaCombobox.Items.Add(isi.Item("dataconcat"))
        Next
    End Sub



End Module
